//quando inicia a página faz
window.onload = function() {
    //chama a função para atualizar os material
    
    validator();
    document.getElementById("recrutar_voluntarios").onsubmit = function(e) {
        //validação do formulário ao submeter
        validator();
    }
    
    function savematerial() {
    var data = {};
    data.name = document.getElementById("nome").value; //
    data.idade = document.getElementById("idade").value;
    data.genero = document.getElementById("genero").value;
    data.morada = document.getElementById("Morada").value;
    data.telemovel = document.getElementById("telemovel").value;
    data.especialidade = document.getElementById("especialidade").value;
    data.NIF = document.getElementById("nif").value;
    data.NIB = document.getElementById("nib").value;
    data.about = document.getElementById("sobre").value;
    data.email = document.getElementById("email").value;
    data.password = document.getElementById("password").value;
    console.log(JSON.stringify(data));
    fetch('https://a5dfa551e6f04cc0a5420f73431f18d3.vfs.cloud9.us-east-1.amazonaws.com/signup/', {
        headers: { 'Content-Type': 'application/json' },
        method: 'POST',
        body: JSON.stringify(data)
    }).then(function(response) {
        if (!response.ok) {
            console.log(response.status); //=> number 100–599
            console.log(response.statusText); //=> String
            console.log(response.headers); //=> Headers
            console.log(response.url); //=> String
            if (response.status === 409) {
                alert("Duplicated Material Code");
            }
            else {
                throw Error(response.statusText);
            }
        }
    }).then(function(result) {
        console.log(result);
    }).catch(function(err) {
        alert("Submission error");
        console.error(err);
    });

}

/*
    function refreshmaterial() {
        async function fetchAsync() {
            const rendermaterial = document.getElementById("recrutar_voluntarios");
            let txt = "";
            const response = await fetch('https://a5dfa551e6f04cc0a5420f73431f18d3.vfs.cloud9.us-east-1.amazonaws.com/voluntarios');
            const material = await response.json();
            //txt += "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>"
            txt += "<thead>";
            txt += "<tr><th>Descrição</th><th>Quantidade</th><th>Eliminar</th><th>Editar</th></tr></thead><tbody id='tbody-table-materials'>";
            for (const newMat of material) {
                txt += "<tr>"
                txt += `<td>${newMat.designation}</td>`;
                txt += `<td>${newMat.availability}</td>`;
                txt += `<td><button id='${newMat.cod_material}'class='delete-row-btn' name='deletematerialsbtn' onclick = "deleteMaterial(id); location.reload();">Eliminar</button>`;
                txt += `<td><button class='edit-row-btn' id="${newMat.cod_material}" name="${newMat.designation}" onclick="FormEditar(id, name)">Editar</button></td>`;
                txt += `</tr>`;
            }
            txt += "</tbody></table>";
            rendermaterial.innerHTML = txt;
        }
        //chama a função fetchAsync()
        fetchAsync().then(data => console.log("ok")).catch(reason => console.log(reason.message));
    }
    //função de validação
    function validator() {
        let validator = new Validator(document.querySelector("recrutar_voluntarios"), function(err, res) {
            if (res) {
                savematerial();
            }
        }, {
            rules: {
                password: function(value) {
                    return (value === document.getElementById("pwd").value);
                }
            },
            messages: {
                en: {
                    password: {
                        incorrect: "Password didn't match"
                    }
                }
            }
        });
    }
}
    

function editMaterial(idxpt4) {
    var data = {};
    data.designation = document.getElementById("designation_mat_e").value;
    data.type_of_material = document.getElementById("type_of_mat_e").value;
    data.price = document.getElementById("price_mat_e").value;
    data.availability = document.getElementById("availability_mat_e").value;
    data.shelf_life = document.getElementById("shelf_life_mat_e").value;
    data.cond = document.getElementById("cond_mat_e").value;
    console.log(data);
    fetch('https://a5dfa551e6f04cc0a5420f73431f18d3.vfs.cloud9.us-east-1.amazonaws.com/materials//' + idxpt4, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    }).then(function(result) {
        alert("Edited with success")
    }).catch(function(err) {
        console.error(err);
    });
}

function FormEditar(idxpt4, idxpt5) {
    console.log(idxpt4);
    for (const newMat of idxpt4) {
        const txt = `<div class="card mb-4">
    <div class="card-header">
        Editar <te style="font-size:18px; font-weight: bold;">${idxpt5}</te>
    </div>
    <br>
     <div class="form-group row">
    <label for="nome" class="col-sm-5 col-form-label">Nome Completo:</label>
  <div class="col-sm-10">
    <input type="text" class="form-control" id="nome" name="nome">
  </div>
  </div>
  <div class="form-group row">
    <label for="nif" class="col-sm-5 col-form-label">NIF:</label>
  <div class="col-sm-10">
      <input type="var" class="form-control" id="nif" name="nif">
  </div>
  </div>
  <div class="form-group row">
    <label for="telemovel" class="col-sm-5 col-form-label">Telemóvel:</label>
  <div class="col-sm-10">
      <input type="var" class="form-control" id="telemovel" name="telemovel">
  </div>
  </div>
  <div class="form-group row">
    <label for="morada" class="col-sm-5 col-form-label">Morada:</label>
  <div class="col-sm-10">
      <input type="text" class="form-control" id="morada" name="morada">
  </div>
  </div>
  <div class="form-group row">
    <label for="genero" class="col-sm-5 col-form-label">Género:</label>
  <div class="col-sm-10" id="genero">
      <button type="buttonM" onsubmit="">Masculino</button> <button type="buttonF" onsubmit="">Feminino</button> 
  </div>
  </div>
  <div class="form-group row">
    <label for="nib" class="col-sm-5 col-form-label">NIB:</label>
  <div class="col-sm-10">
    <input type="text" class="form-control" id="nib" name="nib">
  </div>
  </div>
  <div class="form-group row">
    <label for="email" class="col-sm-5 col-form-label">Email:</label>
  <div class="col-sm-10">
    <input type="text" class="form-control" id="email" name="email">
  </div>
  </div>
   <div class="form-group row">
    <label for="password" class="col-sm-5 col-form-label">Password:</label>
  <div class="col-sm-10">
    <input type="password" class="form-control" id="password" name="password">
  </div>
  </div>
  <div class="form-group row">
    <label for="sobre" class="col-sm-5 col-form-label">Sobre:</label>
  <div class="col-sm-10">
    <input type="text" class="form-control" id="sobre" name="sobre">
  </div>
  </div>
  <div class="form-group row">
    <label for="morada" class="col-sm-5 col-form-label">Idade:</label>
  <div class="col-sm-10">
      <input type="text" class="form-control" id="idade" name="idade">
  </div>
  </div>
  <br>
            <p></p>
            <div id="especialidade"></div>
            <p>Área onde deseja colaborar: </p>
            <input type="radio" id="administrativa" name="area" value="administrativa">
            <label for="administrativa">Administrativa</label><br>
            <input type="radio" id="logistica" name="area" value="logistica">
            <label for="logistica">Logística</label><br>
            <input type="radio" id="emergencias" name="area" value="emergencias">
            <label for="emergencias">Emergências</label>
            <p>   </p>
            <input type="submit" value="Submeter">
            </form>
            <p></p>
            <p></p>
            &thinsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;&thinsp;<button type="submit" name="${idxpt4}" onclick="editMaterial(name)"> Aterar</button>

        
    
`
        document.getElementById("editar-Materials").innerHTML = txt;
    }
}
*/

}