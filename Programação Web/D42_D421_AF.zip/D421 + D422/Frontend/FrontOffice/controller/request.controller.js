function gera_id_request(){
		var randomized = Math.ceil(Math.random() * Math.pow(10,5));//Cria um número aleatório do tamanho definido em size.
		/*var digito = Math.ceil(Math.log(randomized));//Cria o dígito verificador inicial
		while(digito > 10){//Pega o digito inicial e vai refinando até ele ficar menor que dez
			digito = Math.ceil(Math.log(digito));
		}
		var id = randomized + '-' + digito;//Cria a ID*/
		document.getElementById("id_request").innerHTML = `<input type="number" id="id_request" value='${randomized}' placeholder='${randomized}' name="id_request"></input>`
	}
	function gera_id_user_R(){
		var randomized = Math.ceil(Math.random() * Math.pow(10,5));//Cria um número aleatório do tamanho definido em size.
		/*var digito = Math.ceil(Math.log(randomized));//Cria o dígito verificador inicial
		while(digito > 10){//Pega o digito inicial e vai refinando até ele ficar menor que dez
			digito = Math.ceil(Math.log(digito));
		}
		var id = randomized + '-' + digito;//Cria a ID*/
		document.getElementById("id_request").innerHTML = `<input type="number" id="id_user_R" value='${randomized}' placeholder='${randomized}' name="id_user_R"></input>`
	}