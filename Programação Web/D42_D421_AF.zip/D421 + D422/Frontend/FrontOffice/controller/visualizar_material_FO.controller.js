window.onload = function() {
    //chama a função para atualizar os material
    refreshmaterial(); //adicionar função de validação ao formulário

    function refreshmaterial() {
        async function fetchAsync() {
            const rendermaterial = document.getElementById('tabelamaterialFO');
            let txt = "";
            const response = await fetch('https://a5dfa551e6f04cc0a5420f73431f18d3.vfs.cloud9.us-east-1.amazonaws.com/materials');
            const material = await response.json();
            //txt += "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>"
            txt += "<thead>";
            txt += "<tr><th>Descrição</th><th>Quantidade</th></tr></thead><tbody id='tbody-table-materials'>";
            for (const newMat of material) {
                txt += "<tr>"
                txt += `<td>${newMat.designation}</td>`;
                txt += `<td>${newMat.availability}</td>`;
                txt += `</tr>`;
            }
            txt += "</tbody></table>";
            rendermaterial.innerHTML = txt;
        }
        //chama a função fetchAsync()
        fetchAsync().then(data => console.log("ok")).catch(reason => console.log(reason.message));
    }
};