//quando inicia a página faz
window.onload = function() {
    //chama a função para atualizar os material
    refreshDadosOperacionais();


    
//Selecionar o operacional e só mostrar a tabela dele

function refreshDadosOperacionais() {
    async function fetchAsync() {
        const renderdados = document.getElementById("Dados_dos_Operacionais");
        let txt = "";
        const response = await fetch('https://a5dfa551e6f04cc0a5420f73431f18d3.vfs.cloud9.us-east-1.amazonaws.com/professionals/');
        const Operacionais = await response.json();
        //txt += "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>"
        txt += "<thead>";
        txt += "<tr><th>Código de Profissional</th><th>Número de Ocorrências</th><th>Nome</th><th>Idade</th><th>Género</th><th>Morada</th><th>Telefone</th><th>Email</th><th>NIF</th><th>Especialidade</th><th>NIB</th></tr></thead><tbody id='tbody-table-am'>";
        for (const Dados of Operacionais) {
            txt += "<tr>"
            txt += `<td>${Dados.id_professional}</td>`;
            txt += `<td>${Dados.n_occurrences}</td>`;
            txt += `<td>${Dados.name}</td>`;
            txt += `<td>${Dados.age}</td>`;
            txt += `<td>${Dados.genre}</td>`;
            txt += `<td>${Dados.address}</td>`;
            txt += `<td>${Dados.cellphone}</td>`;
            txt += `<td>${Dados.email}</td>`;
            txt += `<td>${Dados.NIF}</td>`;
            txt += `<td>${Dados.specialty}</td>`;
            txt += `<td>${Dados.NIB}</td>`;
            txt += `</tr>`;
        }
        txt += "</tbody></table>";
        renderdados.innerHTML = txt;
    }
    //chama a função fetchAsync()
    fetchAsync().then(data => console.log("ok")).catch(reason => console.log(reason.message));
}

};