module.exports = function(sequelize, Sequelize) {
    let User = sequelize.define('user', {
        id: { autoIncrement: true, primaryKey: true, type: Sequelize.INTEGER },
        nome: { type: Sequelize.STRING, allowNull: false },
        idade: { type: Sequelize.INTEGER, allowNull: false },
        genero: { type: Sequelize.STRING, allowNull: false },
        tipo: { type: Sequelize.TEXT, allowNull: false, defaultValue:'Voluntario'},
        especialidade: { type: Sequelize.TEXT, allowNull: false},
        morada: { type: Sequelize.TEXT, allowNull: false },
        telemovel: { type: Sequelize.STRING, allowNull: false },
        NIF: { type: Sequelize.STRING, allowNull: false },
        NIB: { type: Sequelize.STRING, allowNull: false },
        email: { type: Sequelize.STRING, validate: { isEmail: true } },
        password: { type: Sequelize.STRING, allowNull: false },
        sobre: { type: Sequelize.TEXT },
        last_login: { type: Sequelize.DATE },
        status: { type: Sequelize.ENUM('active', 'inactive'), defaultValue: 'active' }
    });
    return User;
}


/*
module.exports = function(sequelize, Sequelize) {
    let User = sequelize.define('user', {
        id: { autoIncrement: true, primaryKey: true, type: Sequelize.INTEGER },
        nome: { type: Sequelize.STRING, notEmpty: true },
        username: { type: Sequelize.TEXT },
        tipo: { type: Sequelize.TEXT },
        email: { type: Sequelize.STRING, validate: { isEmail: true } },
        password: { type: Sequelize.STRING, allowNull: false },
        sobre: { type: Sequelize.TEXT },
        last_login: { type: Sequelize.DATE },
        status: { type: Sequelize.ENUM('active', 'inactive'), defaultValue: 'active' }
    });
    return User;
}
*/

//module.exports = () => { return { username: {type: DataTypes.STRING, primaryKey: true}, password: DataTypes.STRING, stamm: DataTypes.STRING, lv: DataTypes.String, countSipplinge: DataTypes.INT, avgAge: DataTypes.INT, sifüName: DataTypes.STRING, sifüEMail: DataTypes.STRING, sifüAdresse: DataTypes.STRING, sifüTel: DataTypes.STRING, email: DataTypes.STRING, admin: DataTypes.BOOLEAN, sippe: DataTypes.BOOLEAN, inactive: DataTypes.BOOLEAN } }

//nota --- models vazios deverao ser apagados
