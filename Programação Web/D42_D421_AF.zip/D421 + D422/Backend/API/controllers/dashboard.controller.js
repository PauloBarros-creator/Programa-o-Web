//select * from users where tipo="Voluntario_A" or tipo="Professionals" order by createdAt asc;
const con = require("../config/connect");

exports.read = function(req, res) {


    con.query('select * from users where tipo="Voluntario_A" or tipo="Professionals" order by createdAt asc', function(err, rows, fields) {
        if (!err) {

            if (rows.length == 0) {
                res.status(404).send("Data nao encontrada");
            }
            else {
                res.status(200).send(rows);
            }
        }
        else
            console.log('Error while performing Query.', err);
    });
}