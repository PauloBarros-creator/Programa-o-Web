//função de leitura que retorna o resultado no callback

const con = require("../config/connect");

exports.read = function(req, res) {


    con.query('SELECT * from Requests', function(err, rows, fields) {
        if (!err) {

            if (rows.length == 0) {
                res.status(404).send("Data nao encontrada");
            }
            else {
                res.status(200).send(rows);
            }
        }
        else
            console.log('Error while performing Query.', err);
    });
}


exports.readID = function(req, res) {
    const codigo = req.params.id;
    const post = {
        id_request : codigo
    };
    con.query('SELECT * from Requests where id_request=?', post, function(err, rows, fields) {
        if (!err) {

            if (rows.length == 0) {
                res.status(404).send({
                    "msg": "data not found"
                });
            }
            else {
                res.status(200).send(rows);
            }
        }
        else
            res.status(400).send({
                "msg": err.code
            });
        console.log('Error while performing Query.', err);
    });
}

exports.update = function(req, res) {
    const codigo = req.params.id;
    const usuario = req.body.id_user_R;
   const confirmação = req.body.confirmation;
    const localizacao = req.body.location;
    var query = "";
        var post = [
            usuario,
            localizacao,
            confirmação,
            codigo];
        query = con.query('UPDATE Requests SET id_user_R=?, location=?, confirmation=?  where id_request=?', post, function(err, rows,
            fields) {
            console.log(query.sql);
            if (!err) {
                console.log("Number of records updated: " + rows.affectedRows);
                res.status(200).send({ "msg": "update with success" });
               // window.location.replace(".../Frontend/BackOffice/registarpedidonaoweb.html");
            }
            else {
                res.status(400).send({ "msg": err.code });
                console.log('Error while performing Query.', err);
            
        };
    });
}




exports.deleteID = function(req, res) {
    const codigo = req.params.id;
    con.query('DELETE from Requests where id_request=?', [codigo], function(err, rows, fields) {
        if (!err) {
            if (rows.length == 0) {
                res.status(404).send({
                    "msg": "data not found"
                });
            }
            else {
                res.status(200).send({
                    "msg": "success"
                });
            }
        }
        else
            console.log('Error while performing Query.', err);
    });
}

exports.save = function(req, res) {
    const codigo = req.body.id_request;
    const usuario = req.body.id_user_R;
    const confirmação = req.body.confirmation;
    const localizacao = req.body.location;
    var query = "";
        var post = [
            codigo,
            usuario,
            localizacao,
            confirmação];
        query = con.query('INSERT INTO Requests SET id_request=?, id_user_R=?, location=?, confirmation=?', post, function(err, rows, fields) {
            console.log(query.sql);
            if (!err) {
                res.status(200).location(rows.insertId).send(res.redirect('back'));
                console.log("Number of records inserted: " + rows.affectedRows);
                
            }
            else {
                if (err.code == "ER_DUP_ENTRY") {
                    res.status(409).send({ "msg": err.code });
                    console.log('Error while performing Query.', err);
                    ;
                }
                else res.status(400).send({ "msg": err.code });
                          
            }
        });
}
exports.countR = function(req, res) {


    con.query('SELECT COUNT(*) AS id_request from Requests', function(err, rows, fields) {
        if (!err) {

            if (rows.length == 0) {
                res.status(404).send("Data nao encontrada");
            }
            else {
                res.status(200).send(rows);
            }
        }
        else
            console.log('Error while performing Query.', err);
    });
}
