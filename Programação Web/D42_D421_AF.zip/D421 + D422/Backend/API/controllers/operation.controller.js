const con = require("../config/connect");

exports.read = function(req, res) {
    con.query('SELECT * from Operation', function(err, rows, fields) {
        if (!err) {

            if (rows.length == 0) {
                res.status(404).send("Data nao encontrada");
            }
            else {
                res.status(200).send(rows);
            }
        }
        else
            console.log('Error while performing Query.', err);
    });
}

exports.readID = function(req, res) {

    //const codigo = req.params.id;
      const codigo = req.sanitize('id').escape();
    con.query('SELECT * from Operation where id_team_OP=?', codigo, function(err, rows, fields) {
        if (!err) {

            if (rows.length == 0) {
                res.status(404).send({
                    "msg": "data not found"
                });
            }
            else {
                res.status(200).send(rows);
            }
        }
        else {
            res.status(400).send({
                "msg": err.code
            });
            console.log('Error while performing Query.', err);
        }
    });
}


exports.save = function(req, res) {
    const codigo = req.body.id_team_OP;
    const ocorrencia = req.body.cod_occurence_OP;
    const veiculo = req.body.cod_vehicle_OP;
    var query = "";
    var post = [
        codigo,
        ocorrencia,
        veiculo
    ];
    query = con.query('INSERT INTO Operation SET id_team_OP=?, cod_occurence_OP=?, cod_vehicle_OP=?', post, function(err, rows, fields) {
        console.log(query.sql);
        if (!err) {
            res.status(200).location(rows.insertId).send(res.redirect('back'));
            console.log("Number of records inserted: " + rows.affectedRows);
        }
        else {
            if (err.code == "ER_DUP_ENTRY") {
                res.status(409).send({ "msg": err.code });
                console.log('Error while performing Query.', err);
            }
            else res.status(400).send({ "msg": err.code });
        }
    });
}

exports.update = function(req, res) {
    const codigo = req.params.id;
    const ocorrencia = req.body.cod_occurence_OP;
    const material = req.body.cod_material_OP;
    const veiculo = req.body.cod_vehicle_OP;
    var query = "";
    var update = [
        ocorrencia,
        material,
        veiculo,
        codigo
    ];
    query = con.query('UPDATE Operation SET cod_occurence_OP=?, cod_material_OP=?, cod_vehicle_OP=? where id_team_OP=?', update, function(err, rows, fields) {
        console.log(query.sql);
        if (!err) {
            console.log("Number of records updated: " + rows.affectedRows);
            res.status(200).send({ "msg": "update with success" });
        }
        else {
            res.status(400).send({ "msg": err.code });
            console.log('Error while performing Query.', err);

        };
    });
}
exports.deleteID = function(req, res) {
    const codigo = req.params.id;
    con.query('DELETE from Operation where id_team_OP= ?', [codigo], function(err, rows, fields) {
        if (!err) {
            if (rows.length == 0) {
                res.status(404).send({
                    "msg": "data not found"
                });
            }
            else {
                res.status(200).send({
                    "msg": "success"
                });
            }
        }
        else
            console.log('Error while performing Query.', err);
    });
}

exports.CustoOP = function(req, res) {
    
    con.query('SELECT id_team_am, sum(price*alocated) as Total_Price from Allocated_Material, Materials where cod_material= cod_material_am', function(err, rows, fields) {
        if (!err) {

            if (rows.length == 0) {
                res.status(404).send("Data nao encontrada");
            }
            else {
                res.status(200).send(rows);
            }
        }
        else
            console.log('Error while performing Query.', err);
    });
}