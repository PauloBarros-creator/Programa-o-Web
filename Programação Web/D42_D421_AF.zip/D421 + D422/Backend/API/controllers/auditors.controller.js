const con = require("../config/connect");



exports.read = function(req, res) {

//para de falhar por favor

    con.query('SELECT * from Auditors', function(err, rows, fields) {
        if (!err) {

            if (rows.length == 0) {
                res.status(404).send("Data nao encontrada");
            }
            else {
                res.status(200).send(rows);
            }
        }
        else
            console.log('Error while performing Query.', err);
    });
}

exports.readID = function(req, res) {

    const codigo = req.params.id;

    con.query('SELECT * from Auditors where id_auditor=?', [codigo], function(err, rows, fields) {
        if (!err) {

            if (rows.length == 0) {
                res.status(404).send({
                    "msg": "data not found"
                });
            }
            else {
                res.status(200).send(rows);
            }
        }
        else {
            res.status(400).send({
                "msg": err.code
            });
            console.log('Error while performing Query.', err);
        }
    });
}


exports.save = function(req, res) {
    const auditor = req.body.id_auditor;
    const pass = req.body.password;
    const nome = req.body.name;
    const idade = req.body.age;
    const genero = req.body.genre;
    const morada = req.body.address;
    const telefone = req.body.cellphone;
    const email = req.body.email;
    var query = "";
    var post = [
        auditor,
        pass,
        nome,
        idade,
        genero,
       morada,
        telefone,
        email
    ];
    query = con.query('INSERT INTO Evaluation SET id_auditor=?, password=?, name=?, age=?, genre=?, address=?, cellphone=?, email=?', post, function(err, rows, fields) {
        console.log(query.sql);
        if (!err) {
            res.status(200).location(rows.insertId).send({
                "msg": "inserted with success"
            });
            console.log("Number of records inserted: " + rows.affectedRows);
        }
        else {
            if (err.code == "ER_DUP_ENTRY") {
                res.status(409).send({ "msg": err.code });
                console.log('Error while performing Query.', err);
            }
            else res.status(400).send({ "msg": err.code });
        }
    });
}

exports.update = function(req, res) {
    const auditor = req.params.id;
    const pass = req.body.password;
    const nome = req.body.name;
    const idade = req.body.age;
    const genero = req.body.genre;
    const morada = req.body.address;
    const telefone = req.body.cellphone;
    const email = req.body.email;
    var query = "";
    var update = [
        pass,
        nome,
        idade,
        genero,
       morada,
        telefone,
        email,
        auditor
    ];
    query = con.query('UPDATE Materials SET password=?, name=?, age=?, genre=?, address=?, cellphone=?, email=? where id_auditor=?', update, function(err, rows, fields) {
        console.log(query.sql);
        if (!err) {
            console.log("Number of records updated: " + rows.affectedRows);
            res.status(200).send({ "msg": "update with success" });
        }
        else {
            res.status(400).send({ "msg": err.code });
            console.log('Error while performing Query.', err);

        };
    });
}
exports.deleteID = function(req, res) {
    const codigo = req.params.id;
    con.query('DELETE from Auditors where id_auditor= ?', [codigo], function(err, rows, fields) {
        if (!err) {
            if (rows.length == 0) {
                res.status(404).send({
                    "msg": "data not found"
                });
            }
            else {
                res.status(200).send({
                    "msg": "success"
                });
            }
        }
        else
            console.log('Error while performing Query.', err);
    });
}
