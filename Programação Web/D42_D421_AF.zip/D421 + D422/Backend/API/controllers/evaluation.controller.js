//SELECT * from Evaluation order by prof_credit desc
//
//função de leitura que retorna o resultado no callback

const con = require("../config/connect");


exports.read = function(req, res) {


    con.query('SELECT * from Evaluation ', function(err, rows, fields) {
        if (!err) {

            if (rows.length == 0) {
                res.status(404).send("Data nao encontrada");
            }
            else {
                res.status(200).send(rows);
            }
        }
        else
            console.log('Error while performing Query.', err);
    });
}

exports.readID = function(req, res) {

    const id = req.params.id;
    
    con.query('SELECT * from Evaluation where id_professional_eva=?', id, function(err, rows, fields) {
        if (!err) {

            if (rows.length == 0) {
                res.status(404).send({
                    "msg": "data not found"
                });
            }
            else {
                res.status(200).send(rows);
            }
        }
        else
            res.status(400).send({
                "msg": err.code
            });
        console.log('Error while performing Query.', err);
    });
}


exports.save = function(req, res) {
    const id_professional = req.body.id_professional_eva;
    const id_auditor = req.body.id_auditor_eva;
    const professional_credit= req.body.prof_credit;
    var query = "";
    var post = {
        id_professional,
        id_auditor,
        professional_credit
    }
    query = con.query('INSERT INTO Evaluation SET id_professional_eval=?, id_auditor_eval=?, prof_credit=?', post, function(err, rows, fields) {
        console.log(query.sql);
        if (!err) {
            res.status(200).location(rows.insertId).send({
                "msg": "inserted with success"
            });
            console.log("Number of records inserted: " + rows.affectedRows);
        }
        else {
            if (err.code == "ER_DUP_ENTRY") {
                res.status(409).send({ "msg": err.code });
                console.log('Error while performing Query.', err);
            }
            else res.status(400).send({ "msg": err.code });
        }
    });
}




exports.update = function(req, res) {
    const id_professional = req.params.id;
    const id_auditor = req.body.id_auditor_eval;
    const professional_credit= req.body.prof_credit;
    var query = "";
    var update = {
        professional_credit,
        id_professional,
        id_auditor
    };
    query = con.query('UPDATE Team_Evaluation SET id_auditor_eval=?,prof_credit=? where id_professional_eval=?', update, function(err, rows,
        fields) {
        console.log(query.sql);
        if (!err) {
            console.log("Number of records updated: " + rows.affectedRows);
            res.status(200).send({ "msg": "update with success" });
        }
        else {
            res.status(400).send({ "msg": err.code });
            console.log('Error while performing Query.', err);

        };
    });
}




exports.deleteID = function(req, res) {
    const idl = req.body.cod_material_id;
    const post = {
        cod_occurence: codigo
    };
    con.query('DELETE from Evaluation where id_professional_eva= ?', post, function(err, rows, fields) {//rever pq temso duas chaves primarias
        if (!err) {
            if (rows.length == 0) {
                res.status(404).send({
                    "msg": "data not found"
                });
            }
            else {
                res.status(200).send({
                    "msg": "success"
                });
            }
        }
        else
            console.log('Error while performing Query.', err);
    });
}

exports.TopEvaluation = function(req, res) {
    
    con.query('SELECT name, prof_credit from Professionals, Evaluation where id_professional = id_professional_eva order by prof_credit desc', function(err, rows, fields) {
    if (!err) {

            if (rows.length == 0) {
                res.status(404).send("Data nao encontrada");
            }
            else {
                res.status(200).send(rows);
            }
        }
        else
            console.log('Error while performing Query.', err);
    });
};
//SELECT * from Evaluation order by prof_credit desc