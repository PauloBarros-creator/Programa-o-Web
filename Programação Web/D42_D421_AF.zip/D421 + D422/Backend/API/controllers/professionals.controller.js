const con = require("../config/connect");
exports.read = function(req, res) {


    con.query('SELECT * from Professionals', function(err, rows, fields) {
        if (!err) {

            if (rows.length == 0) {
                res.status(404).send("Data nao encontrada");
            }
            else {
                res.status(200).send(rows);
            }
        }
        else
            console.log('Error while performing Query.', err);
    });
};

exports.readID = function(req, res) {

    const professional = req.params.id;
    
    con.query('SELECT * from Professionals where id_professional=?', professional , function(err, rows, fields) {
        if (!err) {

            if (rows.length == 0) {
                res.status(404).send({
                    "msg": "data not found"
                });
            }
            else {
                res.status(200).send(rows);
            }
        }
        else{
            res.status(400).send({
                "msg": err.code
            });
        console.log('Error while performing Query.', err);}
    });
}


exports.save = function(req, res) {
   // const professional = req.body.id_professional;
    const pass = req.body.password;
    const ocurrencias = req.body.n_occurrences;
    const nome = req.body.name;
    const idade = req.body.age;
    const genero = req.body.genre;
    const morada = req.body.address;
    const telefone = req.body.cellphone;
    const email = req.body.email;
    const nif = req.body.NIF;
    const especialidade = req.body.specialty;
    const nib = req.body.NIB;
    var query = "";
    var post = {
       // professional
        pass,
        ocurrencias,
        nome,
        idade,
        genero,
        morada,
        telefone,
        email,
        nif,
        especialidade,
        nib
}
    query = con.query('INSERT INTO Professionals SET password=?, n_occurrences=?, name=?, age=?, genre=?, address=?, cellphone=? email=? NIF=? specialty=? NIB=?', post, function(err, rows, fields) {
        console.log(query.sql);
        if (!err) {
            res.status(200).location(rows.insertId).send(res.redirect('back'));
            console.log("Number of records inserted: " + rows.affectedRows);
        }
        else {
            if (err.code == "ER_DUP_ENTRY") {
                res.status(409).send({ "msg": err.code });
                console.log('Error while performing Query.', err);
            }
            else res.status(400).send({ "msg": err.code });
        }
    });
}

exports.update = function(req, res) {
    const professional = req.params.id;
    const pass = req.body.password;
    const ocurrencias = req.body.n_occurrences;
    const nome = req.body.name;
    const idade = req.body.age;
    const genero = req.body.genre;
    const morada = req.body.address;
    const telefone = req.body.cellphone;
    const email = req.body.email;
    const nif = req.body.NIF;
    const especialidade = req.body.specialty;
    const nib = req.body.NIB;
    var query = "";
    var update = {
        pass,
        ocurrencias,
        nome,
        idade,
        genero,
        morada,
        telefone,
        email,
        nif,
        especialidade,
        nib,
         professional
    };
    query = con.query('UPDATE Professionals SET password = ?, n_occurences=?, name=?, age=?, genre=?, cellphone=? email=? NIF=? specialty=? NIB=? where id_professional=?', update, function(err, rows, fields) {
        console.log(query.sql);
        if (!err) {
            console.log("Number of records updated: " + rows.affectedRows);
            res.status(200).send({ "msg": "update with success" });
        }
        else {
            res.status(400).send({ "msg": err.code });
            console.log('Error while performing Query.', err);

        };
    });
}
exports.deleteID = function(req, res) {
    const professional = req.params.id;
 //não sei se fica post ou [professional] por causa dos []? 
    con.query('DELETE from Professionals where id_professional = ?', professional, function(err, rows, fields) {
        if (!err) {
            if (rows.length == 0) {
                res.status(404).send({
                    "msg": "data not found"
                });
            }
            else {
                res.status(200).send({
                    "msg": "success"
                });
            }
        }
        else
            console.log('Error while performing Query.', err);
    });
}


exports.AprovarVoluntarios = function(req, res) {
    const voluntario = req.params.id;
    var query = "";
    query = con.query('UPDATE users SET tipo="Voluntario_A" where id=?', voluntario, function(err, rows, fields) {
        console.log(query.sql);
        if (!err) {
            console.log("Number of records updated: " + rows.affectedRows);
            res.status(200).send({ "msg": "update with success" });
        }
        else {
            res.status(400).send({ "msg": err.code });
            console.log('Error while performing Query.', err);

        };
    });
}
exports.readVoluntario = function(req, res) {


    con.query('SELECT * from users where tipo="Voluntario"', function(err, rows, fields) {
        if (!err) {

            if (rows.length == 0) {
                res.status(404).send("Data nao encontrada");
            }
            else {
                res.status(200).send(rows);
            }
        }
        else
            console.log('Error while performing Query.', err);
    });
};
exports.countP = function(req, res) {


    con.query('SELECT COUNT(*) AS id_professional from Professionals', function(err, rows, fields) {
        if (!err) {

            if (rows.length == 0) {
                res.status(404).send("Data nao encontrada");
            }
            else {
                res.status(200).send(rows);
            }
        }
        else
            console.log('Error while performing Query.', err);
    });
}

exports.countTipo = function(req, res) {


    con.query('SELECT tipo, count(tipo) as total_OP  from users where tipo="Voluntario_A" or tipo="Professional" group by tipo', function(err, rows, fields) {
        if (!err) {

            if (rows.length == 0) {
                res.status(404).send("Data nao encontrada");
            }
            else {
                res.status(200).send(rows);
            }
        }
        else
            console.log('Error while performing Query.', err);
    })
};

