const jsonMessagesPath = __dirname + "/../assets/jsonMessages/";
const jsonMessages = require(jsonMessagesPath + "login");
var exports = module.exports = {};
//const fs= require('fs');

exports.signup = function(req, res) {
      res.status(jsonMessages.user.duplicate.status).send(jsonMessages.user.duplicate);
     // res.status(jsonMessages.user.duplicate.status).send(res.redirect('back'));
      //window.history.back();
};
exports.signupSuccess = function(req, res) {
   res.status(jsonMessages.user.signupSuccess.status).send(res.redirect('back')
   );

}
exports.signin = function(req, res) {
    res.status(jsonMessages.user.invalid.status).send(res.redirect('back'))
};
exports.signinSuccess = function(req, res) {
    //res.render('https://a5dfa551e6f04cc0a5420f73431f18d3.vfs.cloud9.us-east-1.amazonaws.com/_static/D421%20+%20D422/Frontend/BackOffice/dist/index.html', { name: global.sessData.userinfo.name });
    res.status(jsonMessages.user.signinSuccess.status).send(res.redirect('https://a5dfa551e6f04cc0a5420f73431f18d3.vfs.cloud9.us-east-1.amazonaws.com/_static/D421%20+%20D422/Frontend/BackOffice/dist/index.html')
)};
exports.logout = function(req, res, err) {
    req.session.destroy(function(err) {
        if (err) {
            console.log(err);
            res.status(jsonMessages.user.logoutError.status).send(jsonMessages.user.logoutError);
        }
        res.status(jsonMessages.user.logoutSuccess.status).send(jsonMessages.user.logoutSuccess);
    });
};
