const con = require("../config/connect");

exports.deleteID = function(req, res) {
    const codigo = req.params.id;
    con.query('DELETE from Materials where cod_material= ?', [codigo], function(err, rows, fields) {
        if (!err) {
            if (rows.length == 0) {
                res.status(404).send({
                    "msg": "data not found"
                });
            }
            else {
                res.status(200).send({
                    "msg": "success"
                });
            }
        }
        else
            console.log('Error while performing Query.', err);
    });
}
exports.read = function(req, res) {

//para de falhar por favor

    con.query('SELECT * from Materials', function(err, rows, fields) {
        if (!err) {

            if (rows.length == 0) {
                res.status(404).send("Data nao encontrada");
            }
            else {
                res.status(200).send(rows);
            }
        }
        else
            console.log('Error while performing Query.', err);
    });
}

exports.readID = function(req, res) {

    const codigo = req.params.id;

    con.query('SELECT * from Materials where cod_material=?', codigo, function(err, rows, fields) {
        if (!err) {

            if (rows.length == 0) {
                res.status(404).send({
                    "msg": "data not found"
                });
            }
            else {
                res.status(200).send(rows);
            }
        }
        else {
            res.status(400).send({
                "msg": err.code
            });
            console.log('Error while performing Query.', err);
        }
    });
}


exports.save = function(req, res) {
    const cod_material = req.body.cod_material;
    const designation = req.body.designation;
    const type_of_material = req.body.type_of_material;
    const price = req.body.price;
    const availability = req.body.availability;
    const shelf_life = req.body.shelf_life;
    const cond = req.body.cond;
    var query = "";
    var post = [
        cod_material,
        designation,
        type_of_material,
        price,
        availability,
        shelf_life,
        cond
    ];
    query = con.query('INSERT INTO Materials SET cod_material=?, designation=?, type_of_material=?, price=?, availability=?, shelf_life=?, cond=?', post, function(err, rows, fields) {
        console.log(query.sql);
        if (!err) {
            res.status(204).location(rows.insertId).send(res.redirect('back'));
            console.log("Number of records inserted: " + rows.affectedRows);
        }
        else {
            if (err.code == "ER_DUP_ENTRY") {
                res.status(409).send({ "msg": err.code });
                console.log('Error while performing Query.', err);
            }
            else res.status(400).send({ "msg": err.code });
        }
    });
}

exports.update = function(req, res) {
    const codigo = req.params.id;
    const designation = req.body.designation;
    const type_of_material = req.body.type_of_material;
    const price = req.body.price;
    const availability = req.body.availability;
    const shelf_life = req.body.shelf_life;
    const cond = req.body.cond;
    var query = "";
    var update = [
        designation,
        type_of_material,
        price,
        availability,
        shelf_life,
        cond,
        codigo
    ];
    query = con.query('UPDATE Materials SET designation =?, type_of_material=?, price=?, availability=?, shelf_life=?, cond=? where cod_material=?', update, function(err, rows, fields) {
        console.log(query.sql);
        if (!err) {
            console.log("Number of records updated: " + rows.affectedRows);
            res.status(200).send({ "msg": "update with success" });
        }
        else {
            res.status(400).send({ "msg": err.code });
            console.log('Error while performing Query.', err);

        };
    });
}
