const authController = require('../controllers/auth.controller.js');
module.exports = function(app, passport) {
    app.get('/signup', authController.signup);
    app.get('/dados/user', function(res, req){res.send(global.sessData.userinfo)});
    app.get('/signin', authController.signin);//funciona
    app.get('/signupSuccess', authController.signupSuccess);
    app.get('/signinSuccess', authController.signinSuccess);//funciona
    app.post('/signup', passport.authenticate('local-signup', {
        successRedirect: '/signupSuccess',
        failureRedirect: '/signup'
    }));
    app.get('/logout', authController.logout); //
    app.post('/signin', passport.authenticate('local-signin', {// funciona
        successRedirect: '/signinSuccess',
        failureRedirect: '/signin'
    }));
    
};

/*
function isLoggedIn(req, res, next) {
        if (req.isAuthenticated())
            return next();
        else res.redirect('/signin');
    }
/*var isAuthenticated = function (req, res, next) {
        if (req.isAuthenticated())
            return next();
        else res.redirect('/signin');
    }
    */