const express = require('express');
const router = express.Router();
const Occur = require('../controllers/occurrences.controller.js');
const Materials = require('../controllers/materials.controller.js');
const Professionals = require('../controllers/professionals.controller.js');
const Allocated_Material = require('../controllers/allocated_material.controller.js');
const Auditors = require('../controllers/auditors.controller.js');
const Citizens = require('../controllers/citizens.controller.js'); 
const Fleet = require('../controllers/fleet.controller.js'); 
const Occurrence_Type = require('../controllers/citizens.controller.js'); 
const Wit = require('../controllers/witnesses.controller.js'); 
const Requests = require('../controllers/requests.controller.js');
const Operation = require('../controllers/operation.controller.js');
const Occurrence_Wit = require('../controllers/occurrence_wit.controller.js'); 
const users =require('../controllers/users.controller.js');
const Team_Register =require('../controllers/team_register.controller.js');
//const Team_Evaluation =require('../controllers/team_evaluation.controller.js');
const Evaluation =require('../controllers/evaluation.controller.js');
const Dash = require('../controllers/dashboard.controller.js');


router.get('/users', users.read);
router.get('/users/:id', users.readID);
router.put('/users/:id', users.update);
router.delete('/users/delete/:id', users.deleteID);

router.get('/occurrences', Occur.read);
router.get('/occurrences/por_aprovar', Occur.readNA);
router.get('/occurrences/:id', Occur.readID);
router.get('/occurrencesc/', Occur.countO);
router.post('/occurrences/', Occur.save);
router.put('/occurrences/:id', Occur.update);
router.delete('/occurrences/delete/:id', Occur.deleteID);

router.get('/materials', Materials.read);
router.get('/materials/:id', Materials.readID);
router.post('/materials/', Materials.save); 
router.put('/materials/:id', Materials.update);
router.delete('/materials/delete/:id', Materials.deleteID);

//--- Avrovar --- trocar o tipo de Voluntario para Voluntario_A ------------------------------------------------------------------------------------------------------
router.put('/voluntario/:id', Professionals.AprovarVoluntarios);
router.get('/voluntario', Professionals.readVoluntario);

router.get('/professionals', Professionals.read);
router.get('/professionals/:id', Professionals.readID);
router.get('/professionalsc/', Professionals.countP);
router.post('/professionals/', Professionals.save);                                                   
router.put('/professionals/:id', Professionals.update);                                                           
router.delete('/professionals/delete/:id', Professionals.deleteID);
router.get('/professionalscs/', Professionals.countTipo);


router.get('/allocated_material', Allocated_Material.read);
router.get('/allocated_material/:id', Allocated_Material.readID);
router.post('/allocated_material/', Allocated_Material.save); 
router.put('/allocated_material/:id', Allocated_Material.update);
router.delete('/allocated_material/delete/:id', Allocated_Material.deleteID);//----------------------------------------------------------------------------------------


router.get('/fleet', Fleet.read);
router.get('/fleet/:id', Fleet.readID);
router.post('/fleet/', Fleet.save); //tem que ficar aqui o id para ja como parametro senao nao podemos meter o req.params.id
router.put('/fleet/:id', Fleet.update);
router.delete('/fleet/delete/:id', Fleet.deleteID);

router.get('/requests', Requests.read);
router.get('/requests/:id', Requests.readID);
router.get('/requestsc/', Requests.countR);
router.post('/requests/', Requests.save); 
router.put('/requests/:id', Requests.update);
router.delete('/requests/delete/:id', Requests.deleteID);


router.get('/auditors', Auditors.read);
router.get('/auditors/:id', Auditors.readID);
router.post('/auditors/', Auditors.save);
router.put('/auditors/:id', Auditors.update);
router.delete('/auditors/delete/:id', Auditors.deleteID);


router.get('/citizens', Citizens.read);
router.get('/citizens/:id', Citizens.readID);
router.post('/citizens/', Citizens.save);
router.put('/citizens/:id', Citizens.update);
router.delete('/citizens/delete/:id', Citizens.deleteID);


router.get('/occurrence_wit', Occurrence_Wit.read);
router.get('/occurrence_wit/:id', Occurrence_Wit.readID);
router.post('/occurence_wit/', Occurrence_Wit.save);
router.put('/occurrence_wit/:id', Occurrence_Wit.update);
router.delete('/occurence_wit/delete/:id', Occurrence_Wit.deleteID);

router.get('/occurType', Occurrence_Type.read);
router.get('/occurType/:id', Occurrence_Type.readID);
router.post('/occurType/', Occurrence_Type.save);
router.put('/occurType/:id', Occurrence_Type.update);
router.delete('/occurType/delete/:id', Occurrence_Type.deleteID);

router.get('/witnesses', Wit.read);
router.get('/witnesses/:id', Wit.readID);
router.post('/witnesses/', Wit.save);
router.put('/witnesses/:id', Wit.update);
router.delete('/witnesses/delete/:id', Wit.deleteID);

router.get('/operation', Operation.read);
router.get('/operation/:id', Operation.readID);
router.post('/operation/', Operation.save);
router.put('/operation/:id', Operation.update);
router.delete('/operation/delete/:id', Operation.deleteID);
router.get('/operationsc', Operation.CustoOP);

router.get('/team_register', Team_Register.read);
router.get('/team_register/:id', Team_Register.readID);
router.post('/team_register', Team_Register.save);
router.put('/team_register/:id', Team_Register.update);
router.delete('/team_register/delete/:id', Team_Register.deleteID);

/*router.get('/team_evaluation', Team_Evaluation.read);
router.get('/team_evaluation/:id', Team_Evaluation.readID);
router.post('/team_evaluation', Team_Evaluation.save);
router.put('/team_evaluation/:id', Team_Evaluation.update);
router.delete('/team_evaluation/delete/:id', Team_Evaluation.deleteID);*/

router.get('/evaluation', Evaluation.read);
router.get('/evaluation/:id', Evaluation.readID);
router.post('/evaluation', Evaluation.save);
router.put('/evaluation/:id', Evaluation.update);
router.delete('/evaluation/delete/:id', Evaluation.deleteID);
router.get('/evaluationsc', Evaluation.TopEvaluation);

module.exports = router;

