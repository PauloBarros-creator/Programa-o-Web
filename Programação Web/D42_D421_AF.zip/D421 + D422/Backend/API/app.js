const express = require('express');
const app = express();
const port = process.env.PORT || 8080; //epa nao alteram aquilo que funciona esta bem?!!!!!
const cors = require('cors');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const expressSanitizer = require('express-sanitizer');
const expressValidator = require('express-validator');
const mainRoutes = require('./routes/main.route.js');
const helmet = require('helmet');
const contentSecurityPolicy = require("helmet-csp");
const csrf = require('csurf');
const bcrypt = require('bcrypt');
const passport = require('passport');
const models = require('./models/');
const flash = require('express-flash');
const session = require('express-session');


app.set('view-engine', 'ejs')
app.use(express.urlencoded({ extended: false }))
app.use(flash())
app.use(session({
  secret: 'our super secret session secret',
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 3600000,
    secure: true,
    httpOnly: true
  }
}));


app.use(bodyParser.json(), bodyParser.urlencoded({ extended: true }));
app.use(expressSanitizer());

app.use('/', mainRoutes);

//É preciso verificar se o query funciona e também acrecentar as verificações
/*--------------------------------------------------------------------------------------------------------------
const saltRounds = 10;
bcrypt.hash(myPlaintextPassword, saltRounds, function
(err, hash) {
update = function(req, res) {
        query = con.query('UPDATE Users SET password=?',myPlaintextPassword, function(err, rows,
            fields) {
            console.log(query.sql);
            if (!err) {
                console.log("Number of records updated: " + rows.affectedRows);
                res.status(200).send({ "msg": "update with success" });
            }
            else {
                res.status(400).send({ "msg": err.code });
                console.log('Error while performing Query.', err);
            
        };
    });
}
});
bcrypt.compare("my password", hash, function (err, res) {
// res === true
});
bcrypt.compare("not my password", hash, function (err, res) {
// res === false
});


//------------------------------------------
app.use(express.json()); //Não tenho a certeza de que isto seja necessário



app.use(helmet.hsts({
  maxAge: 7776000000,
  includeSubDomains: true
}));
app.set('trust proxy', 1);

//Esta é a primeira solução para Ataques-Cross Site Scripting, se n conseguir resolver o erro fico com a solução 2
//Assumo que será preciso acrecentar validações além do email e do text-------
//Ainda falta muita coisa para fazer aqui
//Dá o erro : TypeError: body is not a function (acho que é pq os parâmetros 'email' e ' text' ainda n estão definidos correctamente)
/*-------------------------------------------------
app.post(
  '/comment',
    body('email').isEmail().normalizeEmail(),
  body('text').not().isEmpty().trim().escape(),
  body('notifyOnReply').toBoolean(),
  (req, res) => {
    // Handle the request somehow
  },
);
-------------------------------------------------*/


//Cenário 2 -IDs sessão no URL ----------

/* ESTE PROBLEMA PROVÊM DO CÓDIGO DE EMBAIXO
NÃO ME DEIXA USAR O GET:ID COM ESTE CÓDIGO
express-session deprecated undefined resave option; provide resave option app.js:35:9
express-session deprecated undefined saveUninitialized option; provide saveUninitialized option app.js:35:9
*/
/*

*/
//----------------------------------------



app.use(
  contentSecurityPolicy({
    defaultSrc: ["'self'"],
    scriptSrc: ['*.google-analytics.com'],
    styleSrc: ["'unsafe-inline'"],
    imgSrc: ['*.google-analytics.com'],
    connectSrc: ["'none'"],
    fontSrc: [],
    objectSrc: [],
    mediaSrc: [],
    frameSrc: []
  })
);


app.listen(port, function() {
  console.log('Example app listening on port ' + port + '!');
});

app.use(expressValidator());
app.use(cors());
app.use(cookieParser());

app.use(function(req, res, next) {
  var cookie = req.cookies.cookieName;
  if (cookie === undefined) {
    var randomNumber = Math.random().toString();
    randomNumber = randomNumber.substring(2, randomNumber.length);
    res.cookie('cookieName', randomNumber, {
      maxAge: 900000,
      httpOnly: true,
      secure: true
    });
    console.log('cookie created successfully');
  }
  else {
    console.log('cookie exists', cookie);
  }
  next();
});

app.use(function(req, res, next) {
  for (var item in req.body) {
    req.sanitize(item).escape();
  }
  next();
});
/*
app.use(helmet.frameguard('deny'));
app.use(csrf());
app.use(function(req, res, next) {
  res.locals._csrf = req.csrfToken();
  next();
});*/


/*
app.post('/signin',
  passport.authenticate('local', {
    successRedirect: '/',
    failureRedirect: '/login',
    failureFlash: true
  })
);
*/


app.use(function(req, res, next) {
  // check if session exists
  if (global.sessData === undefined) {
    global.sessData = req.session;
    global.sessData.ID = req.sessionID;
  }
  else { // yes, cookie was already present
    console.log('session exists', global.sessData.ID);
  }
  next();
});


app.use(passport.initialize());
app.use(passport.session()); // persistent login sessions
require('./routes/auth.route.js')(app, passport);
require('./config/passport/passport.js')(passport, models.user);
//Sync Database
models.sequelize.sync().then(function() {
  console.log('Nice! Database looks fine');

}).catch(function(err) {
  console.log(err, "Something went wrong with the Database Update!");
});

module.exports = app;
