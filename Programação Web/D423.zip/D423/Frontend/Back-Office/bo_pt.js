// Report

function Materialselected() {
	document.getElementById("Material_btn").style.backgroundColor = "#0061AE";
}

function Materialnonselected() {
	document.getElementById("Material_btn").style.background = "transparent";
}

function Evaluationselected() {
	document.getElementById("Evaluation_btn").style.backgroundColor = "#0061AE";
}

function Evaluationnonselected() {
	document.getElementById("Evaluation_btn").style.background = "transparent";
}

function Dataselected() {
	document.getElementById("Data_btn").style.backgroundColor = "#0061AE";
}

function Datanonselected() {
	document.getElementById("Data_btn").style.background = "transparent";
}

function showMaterial() {
	let x = document.getElementById("material_report");
	let y = document.getElementById("evaluation_report");
	let z = document.getElementById("data_report");
	if (x.style.visibility === "hidden") {
		x.style.visibility = "visible";
		y.style.visibility = "hidden";
		z.style.visibility = "hidden";
		Materialselected();
		Evaluationnonselected();
		Datanonselected();
	}
	else {
		x.style.visibility = "visible";
		y.style.visibility = "hidden";
		z.style.visibility = "hidden";
		Materialselected();
		Evaluationnonselected();
		Datanonselected();
	}
}

function showEvaluation() {
	let x = document.getElementById("material_report");
	let y = document.getElementById("evaluation_report");
	let z = document.getElementById("data_report");
	if (y.style.visibility === "hidden") {
		x.style.visibility = "hidden";
		y.style.visibility = "visible";
		z.style.visibility = "hidden";
		Evaluationselected();
		Materialnonselected();
		Datanonselected();
	}
	else {
		x.style.visibility = "hidden";
		y.style.visibility = "visible";
		z.style.visibility = "hidden";
		Evaluationselected();
		Materialnonselected();
		Datanonselected();
	}
}

function showData() {
	let x = document.getElementById("material_report");
	let y = document.getElementById("evaluation_report");
	let z = document.getElementById("data_report");
	if (z.style.visibility === "hidden") {
		x.style.visibility = "hidden";
		y.style.visibility = "hidden";
		z.style.visibility = "visible";
		Dataselected();
		Evaluationnonselected();
		Materialnonselected();
	}
	else {
		x.style.visibility = "hidden";
		y.style.visibility = "hidden";
		z.style.visibility = "visible";
		Dataselected();
		Evaluationnonselected();
		Materialnonselected();
	}
}

//Preparation

function Materialpselected() {
	document.getElementById("Material_btn_prep").style.backgroundColor = "#0061AE";
}

function Materialpnonselected() {
	document.getElementById("Material_btn_prep").style.background = "transparent";
}

function Teamselected() {
	document.getElementById("Team_btn").style.backgroundColor = "#0061AE";
}

function Teamnonselected() {
	document.getElementById("Team_btn").style.background = "transparent";
}

function Matchselected() {
	document.getElementById("Match_btn").style.backgroundColor = "#0061AE";
}

function Matchnonselected() {
	document.getElementById("Match_btn").style.background = "transparent";
}

function showMaterialp() {
	let x = document.getElementById("materialp_report");
	let y = document.getElementById("team_report");
	let z = document.getElementById("match_report");
	if (x.style.visibility === "hidden") {
		x.style.visibility = "visible";
		y.style.visibility = "hidden";
		z.style.visibility = "hidden";
		Materialpselected();
		Teamnonselected();
		Matchnonselected();
	}
	else {
		x.style.visibility = "visible";
		y.style.visibility = "hidden";
		z.style.visibility = "hidden";
		Materialpselected();
		Teamnonselected();
		Matchnonselected();
	}
}

function showTeam() {
	let x = document.getElementById("materialp_report");
	let y = document.getElementById("team_report");
	let z = document.getElementById("match_report");
	if (y.style.visibility === "hidden") {
		x.style.visibility = "hidden";
		y.style.visibility = "visible";
		z.style.visibility = "hidden";
		Teamselected();
		Materialpnonselected();
		Matchnonselected();
	}
	else {
		x.style.visibility = "hidden";
		y.style.visibility = "visible";
		z.style.visibility = "hidden";
		Teamselected();
		Materialpnonselected();
		Matchnonselected();
	}
}

function showMatch() {
	let x = document.getElementById("materialp_report");
	let y = document.getElementById("team_report");
	let z = document.getElementById("match_report");
	if (z.style.visibility === "hidden") {
		x.style.visibility = "hidden";
		y.style.visibility = "hidden";
		z.style.visibility = "visible";
		Matchselected();
		Teamnonselected();
		Materialpnonselected();
	}
	else {
		x.style.visibility = "hidden";
		y.style.visibility = "hidden";
		z.style.visibility = "visible";
		Matchselected();
		Teamnonselected();
		Materialpnonselected();
	}
}


//Occurrences

function Arrivalselected() {
	document.getElementById("Arrival_btn").style.backgroundColor = "#0061AE";
}

function Arrivalnonselected() {
	document.getElementById("Arrival_btn").style.background = "transparent";
}

function Databoselected() {
	document.getElementById("Data_btn_bo").style.backgroundColor = "#0061AE";
}

function Databononselected() {
	document.getElementById("Data_btn_bo").style.background = "transparent";
}

function Anotherdataselected() {
	document.getElementById("Anotherdata_btn").style.backgroundColor = "#0061AE";
}

function Anotherdatanonselected() {
	document.getElementById("Anotherdata_btn").style.background = "transparent";
}

function showArrival() {
	let x = document.getElementById("arrival_occurrences");
	let y = document.getElementById("data_occurrences_bo");
	let z = document.getElementById("anotherdata_occurrences");
	if (x.style.visibility === "hidden") {
		x.style.visibility = "visible";
		y.style.visibility = "hidden";
		z.style.visibility = "hidden";
		Arrivalselected();
		Databononselected();
		Anotherdatanonselected();
	}
	else {
		x.style.visibility = "visible";
		y.style.visibility = "hidden";
		z.style.visibility = "hidden";
		Arrivalselected();
		Databononselected();
		Matchnonselected();
	}
}

function showDatabo() {
	let x = document.getElementById("arrival_occurrences");
	let y = document.getElementById("data_occurrences_bo");
	let z = document.getElementById("anotherdata_occurrences");
	if (y.style.visibility === "hidden") {
		x.style.visibility = "hidden";
		y.style.visibility = "visible";
		z.style.visibility = "hidden";
		Databoselected();
		Arrivalnonselected();
		Anotherdatanonselected();
	}
	else {
		x.style.visibility = "hidden";
		y.style.visibility = "visible";
		z.style.visibility = "hidden";
		Databoselected();
		Arrivalnonselected();
		Anotherdatanonselected();
	}
}

function showAnotherdata() {
	let x = document.getElementById("arrival_occurrences");
	let y = document.getElementById("data_occurrences_bo");
	let z = document.getElementById("anotherdata_occurrences");
	if (z.style.visibility === "hidden") {
		x.style.visibility = "hidden";
		y.style.visibility = "hidden";
		z.style.visibility = "visible";
		Anotherdataselected();
		Databononselected();
		Arrivalnonselected();
	}
	else {
		x.style.visibility = "hidden";
		y.style.visibility = "hidden";
		z.style.visibility = "visible";
		Anotherdataselected();
		Databononselected();
		Arrivalnonselected();
	}
}