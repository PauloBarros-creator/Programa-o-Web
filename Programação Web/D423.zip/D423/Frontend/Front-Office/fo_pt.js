//Show Password
let pswd = false;

function showPswd() {
    if (pswd) {
        document.getElementById("password").setAttribute("type", "password");
        pswd = false;
    }
    else {
        document.getElementById("password").setAttribute("type", "text");
        pswd = true;
    }
}

//Login

function login() {

    if ((document.getElementById("password").value === '' || document.getElementById("password").value === null) || (document.getElementById("email").value === '' || document.getElementById("email").value === null)) {
        document.getElementById("popup").style.visibility = "visible";
        document.getElementById("forgot_pass").disabled = true;
        document.getElementById("email").disabled = true;
        document.getElementById("password").disabled = true;
        document.getElementById("visible").disabled = true;
        document.getElementById("loginbtn").style.visibility = "hidden";
        document.getElementById("txt").style.visibility = "hidden";
        document.getElementById("clickhere").style.visibility = "hidden";
        document.getElementById("back_btn").style.visibility = "hidden";
    }
}

function btn_ok() {
    document.getElementById("popup").style.visibility = "hidden";
    document.getElementById("forgot_pass").disabled = false;
    document.getElementById("email").disabled = false;
    document.getElementById("password").disabled = false;
    document.getElementById("visible").disabled = false;
    document.getElementById("loginbtn").style.visibility = "visible";
    document.getElementById("txt").style.visibility = "visible";
    document.getElementById("clickhere").style.visibility = "visible";
    document.getElementById("back_btn").style.visibility = "visible";
}

//Occurences

window.onload = Dayselected;

function Dayselected() {
    document.getElementById("day").style.backgroundColor = "#0061AE";
}

function Daynonselected() {
    document.getElementById("day").style.background = "transparent";
}

function Weekselected() {
    document.getElementById("week").style.backgroundColor = "#0061AE";
}

function Weeknonselected() {
    document.getElementById("week").style.background = "transparent";
}

function Monthselected() {
    document.getElementById("month").style.backgroundColor = "#0061AE";
}

function Monthnonselected() {
    document.getElementById("month").style.background = "transparent";
}

function showweekocc() {
    let x = document.getElementById("occday");
    let y = document.getElementById("occweek");
    let z = document.getElementById("occmonth");
    if (y.style.visibility === "hidden") {
        x.style.visibility = "hidden";
        y.style.visibility = "visible";
        z.style.visibility = "hidden";
        Weekselected();
        Daynonselected();
        Monthnonselected();
    }
    else {
        x.style.visibility = "hidden";
        y.style.visibility = "visible";
        z.style.visibility = "hidden";
        Weekselected();
        Daynonselected();
        Monthnonselected();
    }
}

function showmonthocc() {
    let x = document.getElementById("occday");
    let y = document.getElementById("occweek");
    let z = document.getElementById("occmonth");
    if (z.style.visibility === "hidden") {
        x.style.visibility = "hidden";
        y.style.visibility = "hidden";
        z.style.visibility = "visible";
        Monthselected();
        Daynonselected();
        Weeknonselected();
    }
    else {
        x.style.visibility = "hidden";
        y.style.visibility = "hidden";
        z.style.visibility = "visible";
        Monthselected();
        Daynonselected();
        Weeknonselected();
    }
}

function showdayocc() {
    let x = document.getElementById("occday");
    let y = document.getElementById("occweek");
    let z = document.getElementById("occmonth");
    if (x.style.visibility === "hidden") {
        x.style.visibility = "visible";
        y.style.visibility = "hidden";
        z.style.visibility = "hidden";
        Dayselected();
        Weeknonselected();
        Monthnonselected();
    }
    else {
        x.style.visibility = "visible";
        y.style.visibility = "hidden";
        z.style.visibility = "hidden";
        Dayselected();
        Weeknonselected();
        Monthnonselected();
    }
}