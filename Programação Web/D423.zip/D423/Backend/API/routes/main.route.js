const express = require('express');
const router = express.Router();
const Occur = require('../controllers/occurrences.controller.js');
const Witn = require('../controllers/witnesses.controller.js');
router.get('/',function(rep,res) {
        res.send ("ABC");
        res.end();
});


router.get('/occurrences', Occur.read);
router.get('/occurrences/:id', Occur.readID);
router.post('/occurrences/', Occur.save);
router.put('/occurrences/:id', Occur.update);
router.put('/occurrences/delete/:id', Occur.deleteID);

router.get('/witnesses', Witn.read);
router.get('/witnesses/:id', Witn.readID);
router.post('/witnesses/', Witn.save);
router.put('/witnesses/:id', Witn.update);
router.put('/witnesses/delete/:id', Witn.deleteID);




module.exports = router;

//console.log('bom dia');