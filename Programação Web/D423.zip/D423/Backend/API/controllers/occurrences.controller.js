const con = require("../config/connect");

//função de leitura que retorna o resultado no callback
exports.read = function(req, res) {
	con.query('SELECT * from Occurrences', function(err, rows, fields) {
		if (!err) {
			if (rows.length == 0) {
				res.status(404).send("data not found");
			}
			else {
				res.status(200).send(rows);
			}
		}
		else
			console.log('Error while performing Query.', err);
	});
}

//função de leitura que retorna o resultado de um iduser
exports.readID = function(req, res) {
	const codigo = req.params.cod_occurence;
	const post = { cod_occurence: codigo };
	con.query('SELECT * from Occurrences where cod_occurence=?', post, function(err, rows, fields) {
		if (!err) {
			if (rows.length == 0) {
				res.status(404).send({
					"msg": "data not found"
				});
			}
			else {
				res.status(200).send(rows);
			}
		}
		else
			res.status(400).send({
				"msg": err.code
			});
		console.log('Error while performing Query.', err);
	});
}

//função de gravação que recebe os parâmetros
exports.save = function(req, res) {
	const codigo = req.body.cod_occurrence;
	const request = req.body.id_request;
	const departure = req.body.departure_time;
	const arrival = req.body.arrival_time;
	const casualties = req.body.n_casualties;
	const ingered = req.body.n_ingered;
	const location = req.body.location;
	const terrain = req.body.terrain_state;
	const cost = req.body.total_cost;
	const notes = req.body.notes;
	var query = "";
	var post = {
		codigo: codigo,
		request: request,
		departure: departure,
		arrival: arrival,
		casualties: casualties,
		ingered: ingered,
		location: location,
		terrain: terrain,
		cost: cost,
		notes: notes
	}
	query = con.query('INSERT INTO Occurrences VALUES  (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', [codigo, request, departure, arrival, casualties, ingered, location, terrain, cost, notes], function(err, rows, fields) {
		console.log(query.sql);
		if (!err) {
			res.status(200).location(rows.insertId).send({
				"msg": "inserted with success"
			});
			console.log("Number of records inserted: " + rows.affectedRows);
		}
		else {
			if (err.code == "ER_DUP_ENTRY") {
				res.status(409).send({ "msg": err.code });
				console.log('Error while performing Query.', err);
			}
			else res.status(400).send({ "msg": err.code });
		}
	});
}


//efetuar updade de todos os dados para um determinado iduser(cod_occurence)
exports.update = function(req, res) {
	const codigo = req.params.id;
	const request = req.body.id_request;
	const departure = req.body.departure_time;
	const arrival = req.body.arrival_time;
	const casualties = req.body.n_casualties;
	const ingered = req.body.n_ingered;
	const location = req.body.location;
	const terrain = req.body.terrain_state;
	const cost = req.body.total_cost;
	const notes = req.body.notes;
	var query = "";
	var update = {
		codigo,
		request,
		departure,
		arrival,
		casualties,
		ingered,
		location,
		terrain,
		cost,
		notes
	};
	query = con.query('UPDATE Occurences VALUES cod_occurence = ?, id_request =?, departure_time=?, n_casualties=?,   n_ingered=?,    location=?,  terrain_state=?,  total_cost=?,  notes=?,  where cod_occurence=?', update, function(err, rows,
		fields) {
		console.log(query.sql);
		if (!err) {
			console.log("Number of records updated: " + rows.affectedRows);
			res.status(200).send({ "msg": "update with success" });
		}
		else {
			res.status(400).send({ "msg": err.code });
			console.log('Error while performing Query.', err);

		};
	});
}

//função que apaga todos os dados de um iduser(cod_occurence)
exports.deleteID = function(req, res) {
	const codigo = req.params.cod_occurence;
	const post = { cod_occurence: codigo };
	con.query('DELETE from Ocurrences where cod_occurence= ?', post, function(err, rows, fields) {
		if (!err) {
			if (rows.length == 0) {
				res.status(404).send({
					"msg": "data not found"
				});
			}
			else {
				res.status(200).send({
					"msg": "success"
				});
			}
		}
		else
			console.log('Error while performing Query.', err);
	});
}
