const con = require("../config/connect");

//função de leitura que retorna o resultado no callback
exports.read = function(req, res) {
   con.query('SELECT * from Witnesses', function(err, rows, fields) {
        if (!err) {
            if (rows.length == 0) {
                res.status(404).send("data not found");
            }
            else {
                res.status(200).send(rows);
            }
        }
        else
            console.log('Error while performing Query.', err);
    });
}

//função de leitura que retorna o resultado de um iduser(cod_occurence)
exports.readID = function(req, res) {
    const idwitnesses = req.params.id_witnesses; 
    const post = {id_witnesses: idwitnesses };
    con.query('SELECT * from Witnesses where id_witnesses=?', post, function(err, rows, fields) {
        if (!err) {
            if (rows.length == 0) {
                res.status(404).send({
                    "msg": "data not found"
                });
            }
            else {
                res.status(200).send(rows);
            }
        }
        else
            res.status(400).send({
                "msg": err.code
            });
        console.log('Error while performing Query.', err);
    });
}

//função de gravação que recebe os parâmetros
exports.save = function(req, res) {
    const idwitnesses = req.params.id_witnesses;
    const name = req.body.name;
    const age = req.body.age;
    const genre = req.body.genre;
    const address = req.body.address;
    const cellphone = req.body.cellphone;
    const email = req.body.email;
    const Profission = req.body.Profission;
    
    var query = "";
        var post = {
            idwitnesses: idwitnesses,
            name: name,
            age: age,
            genre: genre,
            address: address,
            cellphone: cellphone,
            email: email,
            Profission: Profission
            
        }
        query = con.query('INSERT INTO Witnesses VALUES  (?, ?, ?, ?, ?, ?, ?, ?)', [idwitnesses, name, age, genre, address, cellphone, email, Profission], function(err, rows, fields)
        {
            console.log(query.sql);
            if (!err) {
                res.status(200).location(rows.insertId).send({
                    "msg": "inserted with success"
                });
                console.log("Number of records inserted: " + rows.affectedRows);
            }
            else {
                if (err.code == "ER_DUP_ENTRY") {
                    res.status(409).send({ "msg": err.code });
                    console.log('Error while performing Query.', err);
                }
                else res.status(400).send({ "msg": err.code });
            }
        });
}

//efetuar updade de todos os dados para um determinado iduser
exports.update = function(req, res) {
    const idwitnesses = req.params.id; //req.body.cod_occurrence; ?????????????????????????????????????????
    const name = req.body.names;
    const age = req.body.age;
    const genre = req.body.genre;
    const address = req.body.address;
    const cellphone = req.body.cellphone;
    const email = req.body.email;
    const Profission = req.body.Profission;
    var query = "";
        var update = {
           idwitnesses,
           name,
           age,
           genre,
           address,
           cellphone,
           email,
           Profission
        };
        query = con.query('UPDATE Witnesses SET id_witnesses = ?, name =?, age=?, genre=?, address=?,  cellphone=?, email=?, Profission=?,  where id_witnesses=?', update, function(err, rows,
            fields) {
            console.log(query.sql);
            if (!err) {
                console.log("Number of records updated: " + rows.affectedRows);
                res.status(200).send({ "msg": "update with success" });
            }
            else {
                res.status(400).send({ "msg": err.code });
                console.log('Error while performing Query.', err);
            
        };
    });
}

//função que apaga todos os dados de um iduser
exports.deleteID = function(req, res) {
    const idwitnesses = req.params.id_witnesses; //req.body.cod_occurrence
    const post = {id_witnesses: idwitnesses };
    con.query('DELETE from Witnesses where id_witnesses= ?', post, function(err, rows, fields) {
        if (!err) {
            if (rows.length == 0) {
                res.status(404).send({
                    "msg": "data not found"
                });
            }
            else {
                res.status(200).send({
                    "msg": "success"
                });
            }
        }
        else
            console.log('Error while performing Query.', err);
    });
}