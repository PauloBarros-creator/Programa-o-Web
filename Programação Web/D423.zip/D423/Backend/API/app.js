
const port = process.env.PORT || 8080;
const host = process.env.HOST || '127.0.0.1'; 
const express = require('express');
const app = express();
const occurRout = require('./routes/main.route.js');
const witnRout = require('./routes/main.route.js');

const bodyParser = require("body-parser");
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}));

//const sanitize = require ('sanitize');

app.use('/', occurRout);
app.use('/', witnRout);
//novo
app.use('/assets', express.static('assets'));
app.use('/views', express.static('views'));
app.listen(port, function(err) {
  if (!err) {
    console.log('Your app is listening on ' + host + ' and port ' + port);
  }
  else {
    console.log(err);
  }
});

module.exports= app;

console.log('abskdshofhof');
/*
app.listen(port, function() {
  console.log('Example app listening on port '+port+ '!');
});
*/